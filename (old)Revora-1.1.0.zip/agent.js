// ── Revora Agent v1.3.1 ───────────────────────────────────
// Ported from HOC Puppeteer agent v5 to CDP (chrome-remote-interface)
// Key fixes vs v1.2:
//   - Sidebar scroll-into-view before every interaction (critical on FB)
//   - Dropdown matching uses innerText not aria-label (how FB actually works)
//   - Year/Make use typing-to-filter after opening dropdown (long lists)
//   - Photos: base64 → write to temp .jpg → upload via CDP file input
//   - Vehicle type selected by innerText "Car/Truck" after scrolling to top
//   - All field ops wait for element to be visible before acting
// Fix v1.3.1:
//   - Facebook form is TWO pages: Page 1 = vehicle details + photos,
//     Page 2 (after Next) = Price + Description
//     Price was landing in Mileage because Next was never clicked

const https = require('https');
const http  = require('http');
const cp    = require('child_process');
const fs    = require('fs');
const os    = require('os');
const path  = require('path');

const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRtZWlneWdtbXh3bWt5bmlpenpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI1NzU2NDEsImV4cCI6MjA4ODE1MTY0MX0.hTv4RICUBNWFNLsQEaZVqcbviqD0ZZSinwCzdSLRDJo';
const DATA_DIR  = path.join(os.homedir(), 'AppData', 'Roaming', 'Revora');
const LOG_FILE  = path.join(DATA_DIR, 'agent.log');
const PHOTO_DIR = path.join(DATA_DIR, 'job-photos');

function log(msg) {
  const line = '[' + new Date().toLocaleTimeString() + '] [AGENT] ' + msg;
  console.log(line);
  try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch(e) {}
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Supabase ──────────────────────────────────────────────
function sbRequest(sbPath, method, body) {
  return new Promise((resolve, reject) => {
    const postData = body ? JSON.stringify(body) : null;
    const opts = {
      hostname: 'dmeigygmmxwmkyniizzj.supabase.co',
      path: sbPath, method: method || 'GET',
      headers: {
        'apikey': SUPABASE_ANON,
        'Authorization': 'Bearer ' + SUPABASE_ANON,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation',
        ...(postData ? { 'Content-Length': Buffer.byteLength(postData) } : {})
      }
    };
    const req = https.request(opts, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch(e) { resolve(data); } });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function updateJob(jobId, status, result) {
  try {
    const body = { status, updated_at: new Date().toISOString() };
    if (result) body.result = result;
    await sbRequest('/rest/v1/jobs?id=eq.' + jobId, 'PATCH', body);
    log('Job ' + jobId + ' → ' + status);
  } catch(e) { log('updateJob error: ' + e.message); }
}

async function logToCommLog(repId, vehicleId, action, note) {
  try {
    await sbRequest('/rest/v1/comm_log', 'POST', {
      rep_id: repId, vehicle_id: vehicleId,
      action, note, created_at: new Date().toISOString()
    });
  } catch(e) {}
}

function findChrome() {
  const paths = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    path.join(os.homedir(), 'AppData', 'Local', 'Google', 'Chrome', 'Application', 'chrome.exe')
  ];
  for (const p of paths) { if (fs.existsSync(p)) return p; }
  return null;
}

// ── Body style detection ──────────────────────────────────
function detectBodyStyle(vehicle) {
  const m = (vehicle.model || '').toLowerCase();
  const t = (vehicle.type || vehicle.bodyType || vehicle.body_style || vehicle.category || '').toLowerCase();
  const make = (vehicle.make || '').toLowerCase();

  // 1. CRM type/bodyType field is most reliable — check it first
  if (t.includes('truck') || t.includes('pickup'))           return 'Truck';
  if (t.includes('sedan'))                                   return 'Sedan';
  if (t.includes('coupe'))                                   return 'Coupe';
  if (t.includes('hatchback') || t.includes('hatch'))        return 'Hatchback';
  if (t.includes('convertible') || t.includes('cabriolet'))  return 'Convertible';
  if (t.includes('wagon') || t.includes('estate'))           return 'Wagon';
  if (t.includes('van') || t.includes('minivan'))            return 'Minivan';
  if (t.includes('suv') || t.includes('crossover') || t.includes('cuv')) return 'SUV';

  // 2. Known truck models
  if (['f-150','f150','f-250','f250','f-350','f350','silverado','sierra',
       'ram 1500','ram 2500','ram 3500','tacoma','tundra','canyon',
       'colorado','frontier','ridgeline','ranger','maverick','titan']
    .some(x => m.includes(x))) return 'Truck';

  // 3. Known SUV/crossover models
  if (['rav4','cr-v','crv','hrv','hr-v','pilot','passport','highlander',
       '4runner','sequoia','venza','sienna','odyssey','traverse','tahoe',
       'suburban','yukon','escalade','navigator','expedition','explorer',
       'bronco','escape','edge','flex','terrain','equinox','blazer',
       'trailblazer','envoy','acadia','enclave','outlook','cx-5','cx-9',
       'cx-30','cx-50','cx5','cx9','cx30','cx50','rogue','pathfinder',
       'armada','murano','kicks','qashqai','xterra','santa fe','tucson',
       'palisade','venue','kona','telluride','sorento','sportage','carnival',
       'stinger','q5','q7','q8','x3','x5','x6','x7','gle','glc','gls',
       'glb','gla','ml','gl class','m class','macan','cayenne','panamera',
       'urus','stelvio','levante','qx60','qx80','rdx','mdx','tsx','qx50',
       'rx','nx','gx','lx','ux','e-pace','f-pace','i-pace','f-type',
       'discovery','defender','range rover','sport','velar','evoque',
       'compass','wrangler','grand cherokee','cherokee','renegade',
       'gladiator','durango','commander','4xe']
    .some(x => m.includes(x))) return 'SUV';

  // 4. Known sedan/coupe models
  if (['civic','corolla','camry','accord','altima','malibu','sentra',
       'elantra','fusion','jetta','passat','model 3','model s',
       'charger','challenger','mustang','camaro','corvette','genesis',
       'g70','g80','g90','a3','a4','a5','a6','a7','a8','s3','s4','s5',
       's6','s7','s8','rs3','rs4','rs5','rs6','rs7','3 series','5 series',
       '7 series','m3','m5','m8','c class','e class','s class','a class',
       'cla','cls','gt','amg gt','2 series','4 series','8 series',
       'giulia','ghibli','gransport','model 3','model s','ct4','ct5',
       'ats','cts','xts','300','200','dart','neon','avenger','impala',
       'cruze','sonic','spark','volt','bolt ev','ioniq','elantra',
       'veloster','i30','mirage','lancer','galant','eclipse',
       'legacy','impreza','wrx','brz','86','gr86','supra','gt86',
       'celica','prius','avalon','crown','mazda3','mazda 3','mazda6',
       'mazda 6','6 series','330','340','530','540','740','750',
       'c300','c43','c63','e300','e350','e400','e43','e53','e63',
       's450','s500','s560','s580','s63','s65']
    .some(x => m.includes(x))) return 'Sedan';

  // 5. Known hatchbacks
  if (['golf','yaris','fit','fiesta','focus hatch','polo','i20','i10',
       'swift','baleno','jazz','note','versa note','micra','208','308']
    .some(x => m.includes(x))) return 'Hatchback';

  // 6. Known convertibles
  if (['boxster','911','718','slk','sl class','slc','sl ','clk',
       'beetle convertible','miata','mx-5','z4','m4 convertible']
    .some(x => m.includes(x))) return 'Convertible';

  // 7. Brand-level heuristics — some makes lean heavily sedan/coupe
  // Mercedes C/E/S/A/CLA/CLS Class are sedans/coupes unless type says SUV
  if (make.includes('mercedes') || make.includes('mercedes-benz') || make.includes('benz')) {
    // GL/GLE/GLC/GLS/GLB/GLA/ML = SUV; everything else = Sedan
    if (!m.includes('gl') && !m.includes('ml') && !m.includes('suv')) return 'Sedan';
  }
  if (make.includes('bmw')) {
    // X-series = SUV; numbered series = Sedan/Coupe
    if (m.match(/\bx[1-9]\b/) || m.includes('x series')) return 'SUV';
    if (m.match(/[1-8] series/) || m.match(/m[2-8]\b/)) return 'Sedan';
  }
  if (make.includes('audi')) {
    // Q-series = SUV; A/S/RS series = Sedan
    if (m.match(/\bq[2-9]\b/)) return 'SUV';
    if (m.match(/\b[asr][1-9]\b/)) return 'Sedan';
  }
  if (make.includes('porsche')) {
    if (m.includes('macan') || m.includes('cayenne')) return 'SUV';
    if (m.includes('panamera') || m.includes('taycan')) return 'Sedan';
    if (m.includes('boxster') || m.includes('718') || m.includes('911')) return 'Convertible';
  }

  // 8. Default — Alberta dealer sells mostly SUVs/trucks but log so we can improve
  return 'SUV';
}

// ── Dealership ad template ────────────────────────────────
function buildDescription(vehicle, features, customNote, cleanModel) {
  const fmt = n => n ? '$' + Number(String(n).replace(/[^0-9.]/g, '')).toLocaleString() : '';
  const m   = cleanModel.toLowerCase();

  let typeLabel = 'vehicle';
  if (['f-150','f150','silverado','ram','tacoma','tundra','canyon','colorado','frontier','ridgeline'].some(x => m.includes(x))) typeLabel = 'truck';
  else if (m.includes('suv') || (vehicle.type||'').toLowerCase().includes('suv')) typeLabel = 'SUV';
  else if (m.includes('van')) typeLabel = 'van';
  else if (['civic','corolla','camry','accord','altima','sentra','elantra','malibu'].some(x => m.includes(x))) typeLabel = 'sedan';

  const mileage   = String(vehicle.mileage || '').replace(/[^0-9,]/g, '');
  const engine    = vehicle.engine       || vehicle.engine_type || '';
  const trans     = vehicle.transmission || vehicle.trans       || '';
  const drivetrain= vehicle.drivetrain   || vehicle.drive_type  || '';

  // Build highlights — mileage first, then features, then specs
  const highlights = [];
  if (mileage)    highlights.push(`✔ ${mileage} KM`);
  if (engine && trans) highlights.push(`✔ ${engine} / ${trans}`);
  else if (trans) highlights.push(`✔ ${trans}`);
  if (drivetrain) highlights.push(`✔ ${drivetrain}`);

  // features can be array or newline-separated string
  const featureList = Array.isArray(features)
    ? features.filter(Boolean)
    : String(features || '').split('\n').map(f => f.trim()).filter(Boolean);
  featureList.slice(0, 6).forEach(f => highlights.push(`✔ ${f}`));

  const lines = [
    `${vehicle.year} ${vehicle.make} ${cleanModel}`,
    `💰 Price: ${fmt(vehicle.price)} + GST`,
    `📍 Location: Calgary, AB`,
    `📦 Stock #: ${vehicle.stock || vehicle.stock_number || ''}`,
    '',
    `Looking for a reliable ${typeLabel} that's ready for the road? This ${vehicle.year} ${vehicle.make} ${cleanModel} is a great option whether you're looking for a daily driver, work vehicle, or something comfortable for Alberta roads year-round.`,
    '',
  ];
  if (customNote) { lines.push(customNote); lines.push(''); }
  lines.push('Vehicle Highlights:');
  highlights.forEach(h => lines.push(h));
  lines.push(
    '',
    'This vehicle has been fully inspected and professionally detailed, making it ready for its next owner.',
    '',
    '🚗 Financing Available',
    'We work with multiple lenders and can help with good credit, bad credit, or no credit situations.',
    '',
    '📩 Message me directly for more information, to schedule a test drive, or to get started on financing.',
    '',
    'We are an AMVIC licensed dealer.'
  );
  return lines.join('\n');
}

// ── Write base64 photos to temp .jpg files ────────────────
// Old agent wrote base64 → disk → uploadFile. We do the same.
function saveBase64Photo(b64, destPath) {
  const clean = b64.replace(/^data:image\/\w+;base64,/, '');
  fs.writeFileSync(destPath, Buffer.from(clean, 'base64'));
  return destPath;
}

// Download a real URL to disk
function downloadPhoto(url, destPath) {
  return new Promise((resolve, reject) => {
    const proto = url.startsWith('https') ? https : http;
    const file  = fs.createWriteStream(destPath);
    const req   = proto.get(url, res => {
      if (res.statusCode !== 200) {
        file.close(); fs.unlink(destPath, () => {});
        return reject(new Error('HTTP ' + res.statusCode));
      }
      res.pipe(file);
      file.on('finish', () => { file.close(); resolve(destPath); });
      file.on('error',  e  => { fs.unlink(destPath, () => {}); reject(e); });
    });
    req.on('error', e => { fs.unlink(destPath, () => {}); reject(e); });
    req.setTimeout(15000, () => { req.destroy(); reject(new Error('timeout')); });
  });
}

// Prepare all photos — handles both base64 and URLs
async function preparePhotos(photos, jobId) {
  if (!photos || !photos.length) return [];
  if (!fs.existsSync(PHOTO_DIR)) fs.mkdirSync(PHOTO_DIR, { recursive: true });

  const localPaths = [];
  const maxPhotos  = Math.min(photos.length, 20);

  for (let i = 0; i < maxPhotos; i++) {
    const p   = photos[i];
    const raw = (typeof p === 'string') ? p : (p.url || p.src || p.photo_url || p.image_url || '');
    if (!raw) continue;

    const dest = path.join(PHOTO_DIR, jobId + '_' + i + '.jpg');
    try {
      if (raw.startsWith('data:')) {
        // base64 — write directly to disk (same as old Puppeteer agent)
        saveBase64Photo(raw, dest);
        localPaths.push(dest);
        log('Photo ' + (i+1) + ': saved from base64');
      } else if (raw.startsWith('http')) {
        await downloadPhoto(raw, dest);
        localPaths.push(dest);
        log('Photo ' + (i+1) + ': downloaded from URL');
      }
    } catch(e) {
      log('Photo ' + i + ' failed: ' + e.message);
    }
  }
  log('Photos ready: ' + localPaths.length + '/' + photos.length);
  return localPaths;
}

// ══════════════════════════════════════════════════════════
//  CDP HELPERS — mirror the Puppeteer agent's approach
// ══════════════════════════════════════════════════════════

// Scroll the left sidebar (left < 350px, scrollable) to bring an element
// with matching innerText into the visible viewport — exactly like old agent
const SCROLL_SIDEBAR_JS = `
(function scrollSidebar(labelText, direction) {
  const divs = Array.from(document.querySelectorAll('div'));
  const sidebar = divs.find(d => {
    const s = window.getComputedStyle(d);
    const r = d.getBoundingClientRect();
    return r.left < 350 && r.width > 150 && r.width < 600
      && d.scrollHeight > d.clientHeight + 100
      && (s.overflow + s.overflowY).match(/auto|scroll/);
  }) || document.scrollingElement || document.body;
  if (direction === 'top') { sidebar.scrollTop = 0; return 'reset'; }
  sidebar.scrollTop += 250;
  return sidebar.scrollTop;
})
`;

// Check if an element with text is visible in viewport
const IS_VISIBLE_JS = `
(function isVisible(labelText) {
  const all = Array.from(document.querySelectorAll(
    'input, textarea, [role="combobox"], [role="button"], label, span, div'
  ));
  const el = all.find(e => {
    const t = (e.innerText || e.getAttribute('aria-label') || e.getAttribute('placeholder') || '').trim().toLowerCase();
    return t === labelText.toLowerCase() || t.includes(labelText.toLowerCase());
  });
  if (!el) return false;
  const r = el.getBoundingClientRect();
  return r.top > 60 && r.bottom < window.innerHeight - 60 && r.width > 0;
})
`;

// ══════════════════════════════════════════════════════════
//  MAIN CDP AGENT
// ══════════════════════════════════════════════════════════
async function runCDPAgent(job, sendToUI) {
  const { vehicle, features, customNote, photos } = job.payload;
  const jobId = job.id;

  log('Starting CDP agent for job: ' + jobId);
  log('Vehicle: ' + vehicle.year + ' ' + vehicle.make + ' ' + vehicle.model);
  sendToUI('job-progress', { jobId, status: 'starting', message: 'Launching Chrome…', progress: 5 });

  let CDP;
  try { CDP = require('chrome-remote-interface'); }
  catch(e) {
    log('chrome-remote-interface not installed');
    await updateJob(jobId, 'failed', { error: 'Run: npm install chrome-remote-interface' });
    sendToUI('job-progress', { jobId, status: 'failed', message: '❌ Run: npm install chrome-remote-interface', progress: 0 });
    return;
  }

  const chromePath = findChrome();
  if (!chromePath) {
    await updateJob(jobId, 'failed', { error: 'Chrome not found' });
    sendToUI('job-progress', { jobId, status: 'failed', message: '❌ Chrome not found', progress: 0 });
    return;
  }

  const revoraDataDir = path.join(DATA_DIR, 'chrome-profile');
  if (!fs.existsSync(revoraDataDir)) fs.mkdirSync(revoraDataDir, { recursive: true });

  // Kill leftover Chrome on port 9222
  try {
    const test = await CDP({ port: 9222 });
    await test.close();
    log('Closing existing Chrome on port 9222');
    if (process.platform === 'win32') {
      cp.execSync('taskkill /F /IM chrome.exe /T 2>nul', { stdio: 'ignore' });
      await sleep(1800);
    }
  } catch(e) { /* not running */ }

  log('Launching Revora Chrome on port 9222');
  const chrome = cp.spawn(chromePath, [
    `--user-data-dir=${revoraDataDir}`,
    `--remote-debugging-port=9222`,
    `--no-first-run`,
    `--no-default-browser-check`,
    `--disable-sync`,
    `--start-maximized`,
    `https://www.facebook.com/marketplace/create/vehicle`
  ], { detached: false, stdio: 'pipe' });
  chrome.on('error', e => log('Chrome spawn error: ' + e.message));
  log('Chrome PID: ' + chrome.pid);

  let client;
  try {
    log('Waiting for CDP on port 9222...');
    let connected = false;
    for (let i = 0; i < 15; i++) {
      await sleep(2000);
      try { client = await CDP({ port: 9222 }); connected = true; log('CDP connected attempt ' + (i+1)); break; }
      catch(e) { log('CDP attempt ' + (i+1) + '/15: ' + e.message); }
    }
    if (!connected) throw new Error('CDP not available after 30s');

    const { Page, Runtime, Input, DOM } = client;
    await Page.enable();
    await Runtime.enable();
    await DOM.enable();

    // Helper: run JS expression, return result value
    async function run(expr) {
      const r = await Runtime.evaluate({ expression: expr, returnByValue: true });
      return r.result.value;
    }
    // Helper: run JS expression, return full result (for objectId)
    async function runFull(expr) {
      return Runtime.evaluate({ expression: expr });
    }

    sendToUI('job-progress', { jobId, status: 'filling', message: 'Navigating to Facebook…', progress: 10 });
    await Page.navigate({ url: 'https://www.facebook.com/marketplace/create/vehicle' });

    // ── Wait for form ──────────────────────────────────────
    log('Waiting for Facebook form...');
    sendToUI('job-progress', { jobId, status: 'filling', message: '⏳ Waiting for Facebook…', progress: 12 });
    for (let i = 0; i < 20; i++) {
      await sleep(2000);
      const state = await run(`(function(){
        if (window.location.href.includes('/login')) return 'login';
        const combos = document.querySelectorAll('[role="combobox"],[aria-haspopup="listbox"]');
        if (combos.length >= 1) return 'ready';
        if (document.body?.innerText?.includes('Vehicle for sale')) return 'ready';
        return 'loading';
      })()`);
      log('Form state ' + (i+1) + ': ' + state);
      if (state === 'login') {
        sendToUI('job-progress', { jobId, status: 'waiting_login', message: '🔐 Please log into Facebook in Chrome', progress: 15 });
        // Wait up to 3 minutes for login
        for (let j = 0; j < 36; j++) {
          await sleep(5000);
          const still = await run(`window.location.href.includes('/login') || !!document.querySelector('input[name="email"]')`);
          if (!still) break;
        }
        await Page.navigate({ url: 'https://www.facebook.com/marketplace/create/vehicle' });
        await sleep(3000);
        continue;
      }
      if (state === 'ready') { log('Form is ready!'); break; }
    }

    log('Starting form fill');
    sendToUI('job-progress', { jobId, status: 'filling', message: '🤖 Filling vehicle details…', progress: 18 });

    // ── Clean up vehicle data ──────────────────────────────
    const cleanModel = (vehicle.model || '')
      .replace(/_/g, ' ')
      .replace(/\s+/g, ' ')
      .replace(/\s*(SUV|Truck|Sedan|Coupe|Hatchback|Wagon|Minivan|Van|Convertible|Pickup)\s*$/i, '')
      .replace(new RegExp('^' + (vehicle.make || '').replace(/[-\/\^$*+?.()|[\]{}]/g, '\\$&') + '\\s*', 'i'), '')
      .trim();
    const bodyStyle   = detectBodyStyle(vehicle);
    const mileageRaw  = String(vehicle.mileage || '').replace(/[^0-9]/g, '');
    const mileageNum  = mileageRaw.slice(0, 6); // max 6 digits
    const priceNum    = String(vehicle.price || '').replace(/[^0-9]/g, '');
    const year        = String(vehicle.year || '');
    const description = buildDescription(vehicle, features, customNote, cleanModel);

    log('Clean model: ' + cleanModel);
    log('Body style: ' + bodyStyle);
    log('Description length: ' + description.length + ' chars');

    // ══════════════════════════════════════════════════════
    //  CORE INTERACTION HELPERS
    //  These mirror the Puppeteer agent's scroll-then-act pattern
    // ══════════════════════════════════════════════════════

    // Scroll sidebar until element with labelText is visible (max 15 scrolls)
    async function scrollToVisible(labelText) {
      for (let i = 0; i < 15; i++) {
        const visible = await run(`${IS_VISIBLE_JS}(${JSON.stringify(labelText)})`);
        if (visible) return true;
        await run(`${SCROLL_SIDEBAR_JS}(${JSON.stringify(labelText)}, 'down')`);
        await sleep(500);
      }
      return false;
    }

    // Reset sidebar to top
    async function scrollToTop() {
      await run(`${SCROLL_SIDEBAR_JS}('', 'top')`);
      await sleep(300);
    }

    // Click a dropdown whose innerText/aria-label matches labelText,
    // then select option by innerText match — scrolling the listbox if needed.
    // If useTyping=true, types to filter (for long lists like Year/Make)
    async function selectDropdown(labelText, optionText, useTyping = true) {
      await scrollToVisible(labelText);
      await sleep(300);

      // Click the combobox whose innerText matches the label
      const clicked = await run(`(function(){
        const lbl = ${JSON.stringify(labelText.toLowerCase())};
        const all = Array.from(document.querySelectorAll('[role="combobox"],[role="button"],[aria-haspopup="listbox"]'));
        const el  = all.find(e => {
          const t = (e.innerText || e.getAttribute('aria-label') || e.getAttribute('placeholder') || '').trim().toLowerCase();
          return t === lbl || t.includes(lbl);
        });
        if (el) { el.scrollIntoView({ block: 'center' }); el.click(); return true; }
        return false;
      })()`);
      log('Dropdown "' + labelText + '" click: ' + clicked);
      if (!clicked) { log('Dropdown not found: ' + labelText, 'warn'); return false; }
      await sleep(1200);

      // Try to click option directly first (no typing) by scrolling the listbox
      const foundDirect = await run(`(function(){
        const needle = ${JSON.stringify(optionText.toLowerCase())};
        const opts = Array.from(document.querySelectorAll('[role="option"]'));
        const match = opts.find(o => (o.innerText||'').trim().toLowerCase() === needle)
          || opts.find(o => (o.innerText||'').trim().toLowerCase().includes(needle));
        if (match) { match.scrollIntoView({ block: 'nearest' }); match.click(); return true; }
        // Scroll listbox to find it
        const lb = document.querySelector('[role="listbox"]');
        if (lb) {
          lb.scrollTop = 0;
          for (let i = 0; i < 20; i++) {
            const m2 = Array.from(lb.querySelectorAll('[role="option"]'))
              .find(o => (o.innerText||'').toLowerCase().includes(needle));
            if (m2) { m2.scrollIntoView({ block: 'nearest' }); m2.click(); return true; }
            lb.scrollTop += 150;
          }
        }
        return false;
      })()`);

      if (foundDirect) {
        log('Selected "' + optionText + '" directly');
        await sleep(700);
        return true;
      }

      // Fall back to typing to filter (for Year / Make which have 100s of options)
      if (useTyping) {
        log('Option not visible — typing "' + optionText + '" to filter');
        for (const char of optionText) {
          await Input.dispatchKeyEvent({ type: 'char', text: char });
          await sleep(50);
        }
        await sleep(800);
        const foundAfterType = await run(`(function(){
          const needle = ${JSON.stringify(optionText.toLowerCase())};
          const opts = Array.from(document.querySelectorAll('[role="option"]'));
          const match = opts.find(o => (o.innerText||'').trim().toLowerCase() === needle)
            || opts.find(o => (o.innerText||'').trim().toLowerCase().includes(needle));
          if (match) { match.scrollIntoView({ block: 'nearest' }); match.click(); return true; }
          return false;
        })()`);
        if (!foundAfterType) {
          // Last resort: ArrowDown + Enter
          await Input.dispatchKeyEvent({ type: 'keyDown', key: 'ArrowDown', windowsVirtualKeyCode: 40 });
          await Input.dispatchKeyEvent({ type: 'keyUp',   key: 'ArrowDown', windowsVirtualKeyCode: 40 });
          await sleep(200);
          await Input.dispatchKeyEvent({ type: 'keyDown', key: 'Enter', windowsVirtualKeyCode: 13 });
          await Input.dispatchKeyEvent({ type: 'keyUp',   key: 'Enter', windowsVirtualKeyCode: 13 });
          log('Used ArrowDown+Enter for "' + optionText + '"');
        } else {
          log('Selected "' + optionText + '" after typing');
        }
      }
      await sleep(700);
      return true;
    }

    // Type a value into an input field found by aria-label/placeholder or label text
    // Clears existing content via React native setter before typing
    async function typeField(labelText, value) {
      await scrollToVisible(labelText);
      await sleep(300);

      // Focus the input
      const focused = await run(`(function(){
        const lbl = ${JSON.stringify(labelText.toLowerCase())};
        // Try attribute match
        const inputs = Array.from(document.querySelectorAll('input, textarea'));
        let el = inputs.find(e =>
          (e.getAttribute('aria-label')||'').toLowerCase().includes(lbl) ||
          (e.getAttribute('placeholder')||'').toLowerCase().includes(lbl)
        );
        // Try label element
        if (!el) {
          const labels = Array.from(document.querySelectorAll('label, div, span'));
          const lel = labels.find(e => (e.innerText||'').trim().toLowerCase() === lbl);
          if (lel) {
            el = lel.querySelector('input,textarea')
              || lel.nextElementSibling?.querySelector('input,textarea')
              || lel.parentElement?.querySelector('input,textarea');
          }
        }
        if (!el) return false;
        el.scrollIntoView({ block: 'center' });
        el.focus(); el.click();
        return true;
      })()`);

      if (!focused) { log('Input not found: ' + labelText); return false; }
      await sleep(400);

      // Clear via React native setter (avoids Ctrl+A → Shift+A modifier bug)
      await run(`(function(){
        const el = document.activeElement;
        if (!el) return;
        const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value');
        if (setter && setter.set) setter.set.call(el, '');
        el.dispatchEvent(new Event('input', { bubbles: true }));
      })()`);
      await sleep(150);

      // Type the value character by character
      for (const char of String(value)) {
        await Input.dispatchKeyEvent({ type: 'char', text: char });
        await sleep(35);
      }
      // Trigger React change event
      await run(`(function(){
        const el = document.activeElement;
        if (el) {
          el.dispatchEvent(new Event('change', { bubbles: true }));
          el.dispatchEvent(new Event('blur',   { bubbles: true }));
        }
      })()`);
      await sleep(400);
      log('Typed "' + labelText + '" → "' + value + '"');
      return true;
    }

    // Set description textarea using React native setter (atomic, no typing needed)
    async function setDescription(value) {
      await scrollToVisible('Description');
      await sleep(300);
      const selectors = [
        'textarea[aria-label*="Description" i]',
        'textarea[placeholder*="description" i]',
        'textarea[placeholder*="seller" i]',
        'textarea[placeholder*="tell buyers" i]',
        'textarea[placeholder*="about your vehicle" i]',
        'textarea',
      ];
      for (const sel of selectors) {
        const ok = await run(`(function(){
          const el = document.querySelector(${JSON.stringify(sel)});
          if (!el) return false;
          el.scrollIntoView({ block: 'center' });
          const proto  = HTMLTextAreaElement.prototype;
          const setter = Object.getOwnPropertyDescriptor(proto, 'value');
          if (setter && setter.set) setter.set.call(el, ${JSON.stringify(value)});
          el.dispatchEvent(new Event('input',  { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          el.dispatchEvent(new Event('blur',   { bubbles: true }));
          return true;
        })()`);
        if (ok) { log('Description set via: ' + sel); return true; }
      }
      log('Description setter failed — falling back to typeField');
      return typeField('Description', value);
    }

    // Upload photos via CDP DOM.getDocument + DOM.querySelector → setFileInputFiles
    // This is the reliable CDP equivalent of Puppeteer's fileInput.uploadFile()
    async function uploadPhotos(localPaths) {
      if (!localPaths.length) return;
      const batchSize = 3;
      for (let i = 0; i < localPaths.length; i += batchSize) {
        const batch = localPaths.slice(i, i + batchSize);
        try {
          await sleep(500);
          // Get a fresh root nodeId for each batch (DOM may have re-rendered)
          const doc = await DOM.getDocument({ depth: 0 });
          const { nodeId } = await DOM.querySelector({
            nodeId: doc.root.nodeId,
            selector: 'input[type="file"]'
          });
          if (!nodeId) { log('File input not found — skipping batch'); break; }
          await DOM.setFileInputFiles({ files: batch, nodeId });
          log('Uploaded batch ' + (Math.floor(i / batchSize) + 1) + ': ' + batch.length + ' photo(s)');
          await sleep(4000 + Math.floor(Math.random() * 2000));
        } catch(e) { log('Photo batch ' + Math.floor(i/batchSize) + ' error: ' + e.message); }
      }
    }

    // ══════════════════════════════════════════════════════
    //  FORM FILL SEQUENCE
    //  Facebook vehicle form is a SINGLE scrollable page.
    //  Order: Vehicle type → Year → Make → Model →
    //         Body style → Mileage → Photos → Price → Description
    //  The "Next" button at the bottom only advances the
    //  preview — it does NOT separate price onto a new page.
    // ══════════════════════════════════════════════════════

    // Reset sidebar to top before starting
    await scrollToTop();
    await sleep(500);

    // STEP 1 ── Vehicle type (no typing — short list, direct click)
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Selecting vehicle type…', progress: 15 });
    await selectDropdown('Vehicle type', 'Car/Truck', false);
    await sleep(1000);

    // STEP 2 ── Year (long list → use typing to filter)
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Selecting year ' + year + '…', progress: 22 });
    await selectDropdown('Year', year, true);
    await sleep(500);

    // STEP 3 ── Make (long list → use typing to filter)
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Entering make…', progress: 29 });
    await selectDropdown('Make', vehicle.make, true);
    await sleep(500);

    // STEP 4 ── Model (text input)
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Entering model…', progress: 36 });
    await typeField('Model', cleanModel);

    // STEP 5 ── Body style (short list → no typing)
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Selecting body style…', progress: 40 });
    await selectDropdown('Body style', bodyStyle, false);

    // STEP 6 ── Mileage
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Entering mileage…', progress: 45 });
    await typeField('Mileage', mileageNum);

    // STEP 7 ── Photos
    sendToUI('job-progress', { jobId, status: 'filling', message: '📸 Preparing photos…', progress: 50 });
    const localPhotoPaths = await preparePhotos(photos, jobId);
    if (localPhotoPaths.length > 0) {
      sendToUI('job-progress', { jobId, status: 'filling', message: '📸 Uploading ' + localPhotoPaths.length + ' photo(s)…', progress: 53 });
      await uploadPhotos(localPhotoPaths);
      localPhotoPaths.forEach(f => { try { fs.unlinkSync(f); } catch(e) {} });
      await sleep(1000);
    } else {
      log('No photos to upload');
      sendToUI('job-progress', { jobId, status: 'filling', message: '⚠️ No photos — please add manually', progress: 53 });
    }

    // STEP 8 ── Price
    // Facebook's Price input has NO placeholder and NO aria-label on the input itself.
    // The label "Price" is in a sibling/parent div with innerText "Price".
    // Strategy: scroll to it, find by label innerText walk, triple-click then type.
    // Numeric only — no $ sign (FB shows $ as visual decoration, not input value).
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Entering price…', progress: 60 });
    await scrollToVisible('Price');
    await sleep(500);
    // Diagnostic: log all visible inputs to help debug price field targeting
    const visibleInputs = await run(`(function(){
      return Array.from(document.querySelectorAll('input')).map(i => ({
        placeholder: i.getAttribute('placeholder'),
        aria: i.getAttribute('aria-label'),
        type: i.type,
        name: i.name,
        id: i.id,
        parentText: i.parentElement?.innerText?.trim().slice(0,40)
      }));
    })()`);
    log('Visible inputs: ' + JSON.stringify(visibleInputs));
    const priceEntered = await run(`(function(){
      const val = ${JSON.stringify(priceNum)};
      // Strategy 1: attribute selectors (sometimes present)
      let el = document.querySelector('input[placeholder="Price"]')
            || document.querySelector('input[aria-label="Price"]')
            || document.querySelector('input[placeholder*="price" i]')
            || document.querySelector('input[aria-label*="price" i]');
      // Strategy 2: find label/div/span with exact text "Price", get its input
      if (!el) {
        const labels = Array.from(document.querySelectorAll('label, div, span'));
        for (const lbl of labels) {
          if (lbl.innerText && lbl.innerText.trim() === 'Price') {
            el = lbl.querySelector('input')
              || lbl.nextElementSibling?.querySelector('input')
              || lbl.parentElement?.querySelector('input')
              || lbl.closest('[class]')?.querySelector('input');
            if (el) break;
          }
        }
      }
      // Strategy 3: find "Enter your price" placeholder or label
      if (!el) {
        el = document.querySelector('input[placeholder*="your price" i]')
          || document.querySelector('input[placeholder*="enter price" i]');
      }
      // Strategy 4: the price section has a specific structure —
      // find the section heading "Price" then get first input after it
      if (!el) {
        const headings = Array.from(document.querySelectorAll('div, span, h2, h3'));
        for (const h of headings) {
          if (h.innerText && h.innerText.trim() === 'Price' && h.offsetParent) {
            // Walk siblings/parents to find the input
            let parent = h.parentElement;
            for (let i = 0; i < 5; i++) {
              const inp = parent?.querySelector('input[type="text"], input[type="number"], input:not([type])');
              if (inp) { el = inp; break; }
              parent = parent?.parentElement;
            }
            if (el) break;
          }
        }
      }
      if (!el) return false;
      el.scrollIntoView({ block: 'center' });
      // Triple-click to select all (same as old Puppeteer agent clickCount:3)
      el.click(); el.focus(); el.select();
      // Set via React native setter — no $ sign
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
      if (setter && setter.set) setter.set.call(el, val);
      el.dispatchEvent(new Event('input',  { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur',   { bubbles: true }));
      return el.value || val;
    })()`);
    if (priceEntered) {
      log('Price entered: ' + priceEntered);
    } else {
      // Last resort: Tab from mileage field to price field and type
      log('Price input not found via DOM — using Tab-from-mileage fallback');
      await run(`(function(){
        // Focus mileage first, then Tab to price
        const inputs = Array.from(document.querySelectorAll('input'));
        const mileage = inputs.find(i =>
          (i.getAttribute('aria-label')||'').toLowerCase().includes('mileage') ||
          (i.getAttribute('placeholder')||'').toLowerCase().includes('mileage')
        );
        if (mileage) { mileage.scrollIntoView({block:'center'}); mileage.focus(); }
      })()`);
      await sleep(200);
      await Input.dispatchKeyEvent({ type: 'keyDown', key: 'Tab', windowsVirtualKeyCode: 9 });
      await Input.dispatchKeyEvent({ type: 'keyUp',   key: 'Tab', windowsVirtualKeyCode: 9 });
      await sleep(300);
      for (const char of priceNum) {
        await Input.dispatchKeyEvent({ type: 'char', text: char });
        await sleep(35);
      }
      await run(`document.activeElement?.dispatchEvent(new Event('change',{bubbles:true}))`);
      log('Price entered via Tab fallback');
    }
    await sleep(400);

    // STEP 9 ── Description
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Writing description…', progress: 70 });
    await setDescription(description);

    // ── Pause for review ──────────────────────────────────
    sendToUI('job-progress', {
      jobId, status: 'review',
      message: '👀 Review the listing in Chrome — click Next/Publish when ready',
      progress: 90,
      preview: {
        title: vehicle.year + ' ' + vehicle.make + ' ' + cleanModel,
        price: vehicle.price,
        mileage: vehicle.mileage,
      }
    });
    await updateJob(jobId, 'review', { message: 'Form filled — awaiting rep review' });
    log('Form fill complete → awaiting review');

    await client.close();

  } catch(e) {
    log('CDP agent error: ' + e.message + '\n' + (e.stack || ''));
    if (client) try { await client.close(); } catch(x) {}
    await updateJob(jobId, 'failed', { error: e.message });
    sendToUI('job-progress', { jobId, status: 'failed', message: '❌ Error: ' + e.message, progress: 0 });
  }
}

// ── Export ────────────────────────────────────────────────
module.exports = {
  runJob: async function(job, sendToUI) {
    log('Received job: ' + job.id);
    try {
      await runCDPAgent(job, sendToUI);
      await logToCommLog(
        job.rep_id, job.vehicle_id,
        'posted_to_facebook',
        [job.payload?.vehicle?.year, job.payload?.vehicle?.make, job.payload?.vehicle?.model]
          .filter(Boolean).join(' ')
      );
    } catch(e) {
      log('runJob error: ' + e.message);
      await updateJob(job.id, 'failed', { error: e.message });
    }
  }
};
