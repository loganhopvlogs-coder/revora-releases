const { contextBridge, ipcRenderer } = require('electron');

// Expose safe API to the UI
contextBridge.exposeInMainWorld('revoraAPI', {
  // Auth
  login:      (email, password) => ipcRenderer.invoke('login', { email, password }),
  getSession: ()                => ipcRenderer.invoke('get-session'),
  signOut:    ()                => ipcRenderer.invoke('signout'),

  // Data
  sbFetch:    (path, token)     => ipcRenderer.invoke('sb-fetch', { path, token }),

  // Actions
  openCRM:      ()              => ipcRenderer.invoke('open-crm'),
  openFacebook: ()              => ipcRenderer.invoke('open-facebook'),
  getVersion:   ()              => ipcRenderer.invoke('get-version'),

  // Window controls
  minimize: () => ipcRenderer.send('minimize'),
  maximize: () => ipcRenderer.send('maximize'),
  close:    () => ipcRenderer.send('close'),

  // Listen for jobs from heartbeat
  onNewJob: (callback) => ipcRenderer.on('new-job', (event, job) => callback(job))
});
