// ── Revora Agent v1.0.0 ───────────────────────────────────
// Runs inside Electron main process
// Picks up jobs from Supabase and fills Facebook Marketplace forms

const https = require('https');
const cp    = require('child_process');
const fs    = require('fs');
const os    = require('os');
const path  = require('path');

const SUPABASE_URL  = 'https://dmeigygmmxwmkyniizzj.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRtZWlneWdtbXh3bWt5bmlpenpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI1NzU2NDEsImV4cCI6MjA4ODE1MTY0MX0.hTv4RICUBNWFNLsQEaZVqcbviqD0ZZSinwCzdSLRDJo';

const DATA_DIR  = path.join(os.homedir(), 'AppData', 'Roaming', 'Revora');
const LOG_FILE  = path.join(DATA_DIR, 'agent.log');

function log(msg) {
  const line = '[' + new Date().toLocaleTimeString() + '] [AGENT] ' + msg;
  console.log(line);
  try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch(e) {}
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Supabase HTTP helper ──────────────────────────────────
function sbRequest(sbPath, method, body) {
  return new Promise((resolve, reject) => {
    const postData = body ? JSON.stringify(body) : null;
    const opts = {
      hostname: 'dmeigygmmxwmkyniizzj.supabase.co',
      path: sbPath,
      method: method || 'GET',
      headers: {
        'apikey': SUPABASE_ANON,
        'Authorization': 'Bearer ' + SUPABASE_ANON,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation',
        ...(postData ? { 'Content-Length': Buffer.byteLength(postData) } : {})
      }
    };
    const req = https.request(opts, (res) => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); } catch(e) { resolve(data); }
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

// ── Update job status ─────────────────────────────────────
async function updateJob(jobId, status, result) {
  try {
    const body = { status, updated_at: new Date().toISOString() };
    if (result) body.result = result;
    await sbRequest('/rest/v1/jobs?id=eq.' + jobId, 'PATCH', body);
    log('Job ' + jobId + ' → ' + status);
  } catch(e) {
    log('updateJob error: ' + e.message);
  }
}

// ── Log to comm_log ───────────────────────────────────────
async function logToCommLog(repId, vehicleId, action, note) {
  try {
    await sbRequest('/rest/v1/comm_log', 'POST', {
      rep_id: repId,
      vehicle_id: vehicleId,
      action,
      note,
      created_at: new Date().toISOString()
    });
  } catch(e) {}
}

// ── Find Chrome ───────────────────────────────────────────
function findChrome() {
  const paths = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    path.join(os.homedir(), 'AppData', 'Local', 'Google', 'Chrome', 'Application', 'chrome.exe')
  ];
  for (const p of paths) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// ── Build Facebook description ────────────────────────────
function buildDescription(vehicle, features, customNote) {
  const year  = vehicle.year  || '';
  const make  = vehicle.make  || '';
  const model = vehicle.model || '';
  const price = vehicle.price ? '$' + Number(vehicle.price).toLocaleString() : '';
  const km    = vehicle.mileage ? Number(vehicle.mileage).toLocaleString() : '';
  const stock = vehicle.stock || '';
  const title = (year + ' ' + make + ' ' + model).trim();

  var desc = '';
  desc += title + '\n';
  desc += '💰 Price: ' + (price || 'Call for pricing') + '\n';
  desc += '📍 Location: Calgary, AB\n';
  desc += '📦 Stock #: ' + stock + '\n';
  desc += '\n';
  desc += 'Looking for a reliable vehicle that\'s ready for the road? This ' + title + ' is a great option whether you\'re looking for a daily driver, work vehicle, or something comfortable for Alberta roads year-round.\n';
  desc += '\n';
  desc += 'Vehicle Highlights:\n';
  if (km) desc += '✔ ' + km + ' KM\n';
  if (features && features.length) {
    for (var fi = 0; fi < features.length; fi++) { desc += '✔ ' + features[fi] + '\n'; }
  }
  if (customNote) desc += '✔ ' + customNote + '\n';
  desc += '\n';
  desc += 'This vehicle has been fully inspected and professionally detailed, making it ready for its next owner.\n';
  desc += '\n';
  desc += '🚗 Financing Available\n';
  desc += 'We work with multiple lenders and can help with good credit, bad credit, or no credit situations.\n';
  desc += '\n';
  desc += '📩 Message me directly for more information, to schedule a test drive, or to get started on financing.\n';
  desc += '\n';
  desc += 'We are an AMVIC licensed dealer.';
  return desc;
}

// ── Detect body style ─────────────────────────────────────
function detectBodyStyle(vehicle) {
  const bodyStyleMap = {
    'suv': 'SUV', 'crossover': 'SUV', 'cuv': 'SUV',
    'truck': 'Truck', 'pickup': 'Truck',
    'sedan': 'Sedan',
    'coupe': 'Coupe',
    'hatchback': 'Hatchback', 'hatch': 'Hatchback',
    'wagon': 'Wagon', 'station wagon': 'Wagon',
    'van': 'Minivan', 'minivan': 'Minivan',
    'convertible': 'Convertible',
  };
  const vType  = (vehicle.type || vehicle.bodyType || '').toLowerCase();
  const vModel = (vehicle.model || '').toLowerCase();

  let bodyStyle = 'SUV';
  for (const [key, val] of Object.entries(bodyStyleMap)) {
    if (vType.includes(key) || vModel.includes(key)) { bodyStyle = val; break; }
  }
  // Known truck models
  if (['f-150','silverado','ram','tacoma','tundra','canyon','colorado','frontier','ridgeline']
      .some(t => vModel.includes(t))) bodyStyle = 'Truck';
  // Known sedans
  if (['civic','corolla','camry','accord','altima','fusion','malibu','sentra','elantra','jetta']
      .some(t => vModel.includes(t))) bodyStyle = 'Sedan';
  // Known hatchbacks
  if (['golf','yaris','fit','fiesta','mazda3 sport','impreza hatch']
      .some(t => vModel.includes(t))) bodyStyle = 'Hatchback';

  return bodyStyle;
}

// ── CDP-based form filler ─────────────────────────────────
// Uses Chrome DevTools Protocol via chrome-remote-interface
async function runCDPAgent(job, sendToUI) {
  const { vehicle, features, customNote, photos } = job.payload;
  const jobId = job.id;

  log('Starting CDP agent for job: ' + jobId);
  log('Vehicle: ' + vehicle.year + ' ' + vehicle.make + ' ' + vehicle.model);

  sendToUI('job-progress', { jobId, status: 'starting', message: 'Opening Facebook Marketplace…', progress: 5 });

  // Check if CDP module available, fall back to launch-only mode
  let CDP;
  try {
    CDP = require('chrome-remote-interface');
  } catch(e) {
    log('chrome-remote-interface not installed — using launch-only mode');
    // Just open Chrome to the form, rep fills manually
    const chromePath = findChrome();
    if (chromePath) {
      const revoraFallbackDir = path.join(DATA_DIR, 'chrome-profile');
      if (!fs.existsSync(revoraFallbackDir)) fs.mkdirSync(revoraFallbackDir, { recursive: true });
      cp.spawn(chromePath, [
        '--user-data-dir=' + revoraFallbackDir,
        '--remote-debugging-port=9222',
        '--no-first-run',
        'https://www.facebook.com/marketplace/create/vehicle'
      ], { detached: true, stdio: 'ignore' }).unref();
      await updateJob(jobId, 'review', { message: 'Chrome opened — please fill form manually' });
      sendToUI('job-progress', { jobId, status: 'review', message: 'Chrome opened — waiting for manual fill', progress: 50 });
    }
    return;
  }

  // Launch Chrome with remote debugging
  const chromePath = findChrome();
  if (!chromePath) {
    await updateJob(jobId, 'failed', { error: 'Chrome not found on this computer' });
    sendToUI('job-progress', { jobId, status: 'failed', message: 'Chrome not found', progress: 0 });
    return;
  }

  // Kill any existing Chrome running on debug port to avoid conflicts
  try {
    if (process.platform === 'win32') {
      // Only kill Chrome on port 9222 — never touch the rep's personal Chrome
      const netResult = cp.execSync('netstat -ano | findstr :9222', { encoding: 'utf8', stdio: 'pipe' }).trim();
      if (netResult) {
        const netLines = netResult.split(/\r?\n/).filter(function(l){ return l.includes('LISTENING') || l.includes('ESTABLISHED'); });
        const netPids = netLines.map(function(l){ return l.trim().split(/\s+/).pop(); }).filter(Boolean);
        const uniquePids = netPids.filter(function(v,i,a){ return a.indexOf(v)===i; });
        for (var pi = 0; pi < uniquePids.length; pi++) {
          try { cp.execSync('taskkill /F /PID ' + uniquePids[pi] + ' 2>nul', { stdio: 'ignore' }); } catch(e) {}
        }
        log('Killed Chrome on port 9222 (PIDs: ' + uniquePids.join(', ') + ')');
        await sleep(2500);
      } else {
        log('No Chrome on port 9222 — skipping kill');
      }
    }
  } catch(e) { /* No Chrome on port 9222 */ }
  // Use a completely separate Revora Chrome data dir — never conflicts with personal Chrome
  const revoraDataDir = path.join(DATA_DIR, 'chrome-profile');
  if (!fs.existsSync(revoraDataDir)) fs.mkdirSync(revoraDataDir, { recursive: true });

  // Check if port 9222 is already available (previous Revora Chrome still running)
  let portAlreadyOpen = false;
  try {
    const testClient = await CDP({ port: 9222 });
    await testClient.close();
    portAlreadyOpen = true;
    log('Port 9222 already open — reusing existing Chrome instance');
  } catch(e) {}

  if (!portAlreadyOpen) {
    log('Launching Revora Chrome with remote debugging on port 9222');
    const chrome = cp.spawn(chromePath, [
      `--user-data-dir=${revoraDataDir}`,
      `--remote-debugging-port=9222`,
      `--no-first-run`,
      `--no-default-browser-check`,
      `--disable-default-apps`,
      `--disable-sync`,
      `--disable-extensions`,
      `--window-size=1280,900`,
      `https://www.facebook.com/marketplace/create/vehicle`
    ], { detached: false, stdio: 'pipe' });
    chrome.on('error', e => log('Chrome spawn error: ' + e.message));
    log('Chrome PID: ' + chrome.pid);
    await sleep(4000); // give Chrome time to start before first CDP attempt
  } else {
    log('Reusing existing Chrome on port 9222 — navigating to marketplace form');
  }

  // Wait for Chrome remote debugging to become available (up to 120 seconds)
  let client;
  try {
    let connected = false;
    log('Waiting for Chrome remote debugging port 9222...');
    for (let i = 0; i < 40; i++) {
      await sleep(3000);
      try {
        client = await CDP({ port: 9222 });
        connected = true;
        log('CDP connected on attempt ' + (i+1));
        break;
      } catch(e) {
        log('CDP attempt ' + (i+1) + '/40 failed: ' + e.message);
        // On first few attempts, Chrome may not even be open yet — wait longer
        if (i < 5) await sleep(2000);
      }
    }
    if (!connected) throw new Error('Chrome remote debugging not available after 120s — is Chrome already open on port 9222?');
    const { Page, Runtime, Input, DOM } = client;
    await Page.enable();
    await Runtime.enable();
    await DOM.enable();

    sendToUI('job-progress', { jobId, status: 'filling', message: 'Navigating to Facebook Marketplace…', progress: 10 });

    // Navigate to Facebook Marketplace vehicle listing form
    log('Navigating to Facebook create vehicle form');
    await Page.navigate({ url: 'https://www.facebook.com/marketplace/create/vehicle' });
    
    // Wait for Facebook form to actually be ready (up to 30 seconds)
    log('Waiting for Facebook Marketplace form to load...');
    sendToUI('job-progress', { jobId, status: 'filling', message: '⏳ Waiting for Facebook to load…', progress: 10 });

    let formReady = false;
    for (let i = 0; i < 15; i++) {
      await sleep(2000);
      const check = await Runtime.evaluate({
        expression: `(function() {
          const url = window.location.href;
          if (url.includes('/login')) return 'login';
          // Look for Vehicle type dropdown or Year dropdown — form is ready
          const selects = document.querySelectorAll('select, [role="combobox"], [role="listbox"]');
          const labels = document.querySelectorAll('label, span');
          for (const l of labels) {
            if (l.textContent.includes('Vehicle type') || l.textContent.includes('Year')) return 'ready';
          }
          if (selects.length > 0) return 'ready';
          return 'loading';
        })()`
      });
      const state = check.result.value;
      log('Form state check ' + (i+1) + ': ' + state);
      if (state === 'login') {
        log('Facebook not logged in');
        sendToUI('job-progress', { jobId, status: 'waiting_login', message: '🔐 Please log into Facebook in the Chrome window', progress: 15 });
        await updateJob(jobId, 'review', { message: 'Please log into Facebook first, then try posting again' });
        await client.close();
        return;
      }
      if (state === 'ready') {
        formReady = true;
        log('Form is ready!');
        break;
      }
    }

    if (!formReady) {
      throw new Error('Facebook form did not load after 30 seconds');
    }

    log('Facebook form ready — starting form fill');
    sendToUI('job-progress', { jobId, status: 'filling', message: '🤖 Filling in vehicle details…', progress: 20 });

    // ── React-aware field setter ──────────────────────────────
    // Facebook uses React — we must trigger native input value setter + dispatch events
    async function setReactInput(selector, value) {
      const result = await Runtime.evaluate({
        expression: `
          (function() {
            const el = document.querySelector(${JSON.stringify(selector)});
            if (!el) return false;
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')
              || Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
            if (nativeSetter) nativeSetter.set.call(el, ${JSON.stringify(String(value))});
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            el.dispatchEvent(new Event('blur', { bubbles: true }));
            return true;
          })()
        `
      });
      return result.result.value;
    }

    // Find input by placeholder or aria-label
    async function fillField(identifiers, value) {
      if (!value) return false;
      for (const id of identifiers) {
        const selectors = [
          `input[placeholder*="${id}" i]`,
          `textarea[placeholder*="${id}" i]`,
          `input[aria-label*="${id}" i]`,
          `textarea[aria-label*="${id}" i]`,
        ];
        for (const sel of selectors) {
          const ok = await setReactInput(sel, value);
          if (ok) {
            log('Filled "' + id + '" → ' + value);
            await sleep(400);
            return true;
          }
        }
      }
      // Fallback: find by nearby label text and simulate typing via CDP Input
      const found = await Runtime.evaluate({
        expression: `
          (function() {
            const labels = Array.from(document.querySelectorAll('label, span[class]'));
            for (const label of labels) {
              if (${JSON.stringify(identifiers)}.some(id => label.textContent.trim().toLowerCase().includes(id.toLowerCase()))) {
                const inp = label.querySelector('input,textarea') 
                  || label.parentElement?.querySelector('input,textarea')
                  || label.closest('div[class]')?.querySelector('input,textarea');
                if (inp) { inp.focus(); inp.click(); return true; }
              }
            }
            return false;
          })()
        `
      });
      if (found.result.value) {
        await sleep(300);
        // Select all and type
        await Input.dispatchKeyEvent({ type: 'keyDown', modifiers: 2, key: 'a', windowsVirtualKeyCode: 65 });
        await Input.dispatchKeyEvent({ type: 'keyUp', modifiers: 2, key: 'a', windowsVirtualKeyCode: 65 });
        for (const char of String(value)) {
          await Input.dispatchKeyEvent({ type: 'char', text: char });
          await sleep(25);
        }
        log('Typed "' + identifiers[0] + '" via keystrokes → ' + value);
        await sleep(300);
        return true;
      }
      log('Field not found: ' + identifiers[0]);
      return false;
    }

    // Click a dropdown then select an option from the list
    async function selectDropdown(labelHints, optionText) {
      // Click the combobox
      await Runtime.evaluate({
        expression: `
          (function() {
            const hints = ${JSON.stringify(labelHints)};
            const boxes = Array.from(document.querySelectorAll('[role="combobox"], select, [aria-haspopup="listbox"]'));
            for (const box of boxes) {
              const label = box.getAttribute('aria-label') || box.closest('label')?.textContent || '';
              if (hints.some(h => label.toLowerCase().includes(h.toLowerCase()))) { box.click(); return true; }
            }
            // Try nearby span
            const spans = Array.from(document.querySelectorAll('span,label'));
            for (const s of spans) {
              if (hints.some(h => s.textContent.trim().toLowerCase() === h.toLowerCase())) {
                const box = s.closest('div[class]')?.querySelector('[role="combobox"],[aria-haspopup]');
                if (box) { box.click(); return true; }
              }
            }
          })()
        `
      });
      await sleep(800);
      // Click the option
      await Runtime.evaluate({
        expression: `
          (function() {
            const opt = ${JSON.stringify(optionText)};
            const items = Array.from(document.querySelectorAll('[role="option"], li, [data-value]'));
            for (const item of items) {
              if (item.textContent.trim().toLowerCase().includes(opt.toLowerCase())) {
                item.click(); return true;
              }
            }
          })()
        `
      });
      await sleep(500);
      log('Selected dropdown "' + labelHints[0] + '" → ' + optionText);
    }

    // ── Download photos from Supabase URLs to temp files ──────
    const https = require('https');
    const http = require('http');
    const os = require('os');
    const photoDir = path.join(DATA_DIR, 'job-photos');
    if (!fs.existsSync(photoDir)) fs.mkdirSync(photoDir, { recursive: true });

    async function downloadPhoto(url, destPath) {
      return new Promise((resolve, reject) => {
        const proto = url.startsWith('https') ? https : http;
        const file = fs.createWriteStream(destPath);
        proto.get(url, res => {
          res.pipe(file);
          file.on('finish', () => { file.close(); resolve(destPath); });
        }).on('error', e => { fs.unlink(destPath, () => {}); reject(e); });
      });
    }

    // ── Prepare photos — handles base64 AND real URLs (restored from v1.1.1) ──
    sendToUI('job-progress', { jobId, status: 'filling', message: '📸 Preparing photos…', progress: 50 });

    function saveBase64Photo(b64, destPath) {
      const clean = b64.replace(/^data:image\/\w+;base64,/, '');
      fs.writeFileSync(destPath, Buffer.from(clean, 'base64'));
      return destPath;
    }

    async function preparePhotos(photoList, jId) {
      if (!photoList || !photoList.length) return [];
      const photoDir = path.join(DATA_DIR, 'job-photos');
      if (!fs.existsSync(photoDir)) fs.mkdirSync(photoDir, { recursive: true });
      const localPaths = [];
      const maxPhotos  = Math.min(photoList.length, 20);
      for (let i = 0; i < maxPhotos; i++) {
        const p   = photoList[i];
        const raw = (typeof p === 'string') ? p : (p.url || p.src || p.photo_url || p.image_url || '');
        if (!raw) continue;
        const dest = path.join(photoDir, jId + '_' + i + '.jpg');
        try {
          if (raw.startsWith('data:')) {
            saveBase64Photo(raw, dest);
            localPaths.push(dest);
            log('Photo ' + (i+1) + ': saved from base64');
          } else if (raw.startsWith('http')) {
            await downloadPhoto(raw, dest);
            localPaths.push(dest);
            log('Photo ' + (i+1) + ': downloaded from URL');
          }
        } catch(e) { log('Photo ' + (i+1) + ' failed: ' + e.message); }
      }
      log('Photos ready: ' + localPaths.length + '/' + photoList.length);
      return localPaths;
    }

    const localPhotoPaths = await preparePhotos(photos, jobId);
    if (localPhotoPaths.length) {
      sendToUI('job-progress', { jobId, status: 'filling', message: '📸 Uploading ' + localPhotoPaths.length + ' photo(s)…', progress: 53 });
    } else {
      log('No photos to upload');
      sendToUI('job-progress', { jobId, status: 'filling', message: '⚠️ No photos — please add manually', progress: 53 });
    }



    // ── Upload photos via CDP — batches of 3 (restored from v1.1.1) ──────────
    async function uploadPhotos(localPaths) {
      if (!localPaths.length) return;
      const batchSize = 3;
      for (let i = 0; i < localPaths.length; i += batchSize) {
        const batch = localPaths.slice(i, i + batchSize);
        try {
          await sleep(500);
          // Fresh root nodeId each batch — DOM may re-render after each upload
          const doc = await DOM.getDocument({ depth: 0 });
          const { nodeId } = await DOM.querySelector({
            nodeId: doc.root.nodeId,
            selector: 'input[type="file"]'
          });
          if (!nodeId) { log('File input not found — skipping batch'); break; }
          await DOM.setFileInputFiles({ files: batch, nodeId });
          log('Uploaded batch ' + (Math.floor(i / batchSize) + 1) + ': ' + batch.length + ' photo(s)');
          await sleep(4000 + Math.floor(Math.random() * 2000));
        } catch(e) { log('Photo batch error: ' + e.message); }
      }
    }

    // ── Now fill the form ─────────────────────────────────────
    const year      = String(vehicle.year || '');
    const make      = vehicle.make || '';
    const cleanModel = (vehicle.model || '').replace(/\s+(SUV|Sedan|Coupe|Hatchback|Wagon|Truck|Van|Convertible)$/i, '').trim();
    const mileage   = String(vehicle.mileage || '').replace(/[^0-9]/g, '');
    const price     = String(vehicle.price || '').replace(/[^0-9]/g, '');
    const bodyStyle = detectBodyStyle(vehicle);
    const description = buildDescription(vehicle, features, customNote);

    // Vehicle type (first dropdown)
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Selecting vehicle type…', progress: 22 });
    await selectDropdown(['vehicle type', 'type'], 'Car/Truck');
    await sleep(1000);

    // Wait for Year/Make fields to appear after vehicle type selection
    log('Waiting for Year/Make fields to appear...');
    await sleep(2000);

    // Year — Facebook uses a dropdown not a text input
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Entering year…', progress: 26 });
    const yearFilled = await fillField(['year', 'Year'], year);
    if (!yearFilled) await selectDropdown(['year', 'Year'], year);

    // Make — also may be a dropdown or autocomplete
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Entering make…', progress: 30 });
    const makeFilled = await fillField(['make', 'Make'], make);
    if (!makeFilled) await selectDropdown(['make', 'Make'], make);
    await sleep(800);

    // Model
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Entering model…', progress: 35 });
    const modelFilled = await fillField(['model', 'Model'], cleanModel);
    if (!modelFilled) await selectDropdown(['model', 'Model'], cleanModel);
    await sleep(800);

    // Body style
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Selecting body style…', progress: 40 });
    await selectDropdown(['body style', 'Body style'], bodyStyle);

    // Mileage
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Entering mileage…', progress: 45 });
    await fillField(['mileage', 'Mileage', 'kilometers'], mileage);

    // Price
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Entering price…', progress: 55 });
    await fillField(['price', 'Price'], price);

    // Description — use React setter only (avoid double-type bug)
    sendToUI('job-progress', { jobId, status: 'filling', message: 'Writing description…', progress: 65 });
    const descSelectors = [
      'textarea[placeholder*="description" i]',
      'textarea[aria-label*="description" i]',
      'textarea[placeholder*="seller" i]',
      'textarea[placeholder*="tell buyers" i]',
      '#description',
    ];
    let descSet = false;
    for (const sel of descSelectors) {
      const ok = await setReactInput(sel, description);
      if (ok) { log('Description set via React: ' + sel); descSet = true; break; }
    }
    if (!descSet) {
      // Click the textarea and type
      await Runtime.evaluate({ expression: `
        (function() {
          const ta = document.querySelector('textarea');
          if (ta) { ta.focus(); ta.click(); return true; }
        })()
      `});
      await sleep(300);
      // Clear first
      await Input.dispatchKeyEvent({ type: 'keyDown', modifiers: 2, key: 'a', windowsVirtualKeyCode: 65 });
      await Input.dispatchKeyEvent({ type: 'keyUp', modifiers: 2, key: 'a', windowsVirtualKeyCode: 65 });
      await Input.dispatchKeyEvent({ type: 'keyDown', key: 'Delete', windowsVirtualKeyCode: 46 });
      await Input.dispatchKeyEvent({ type: 'keyUp', key: 'Delete', windowsVirtualKeyCode: 46 });
      for (const char of description) {
        await Input.dispatchKeyEvent({ type: 'char', text: char });
        await sleep(15);
      }
      log('Description typed via keystrokes');
    }

    // Photos
    sendToUI('job-progress', { jobId, status: 'filling', message: '📸 Uploading photos…', progress: 75 });
    await uploadPhotos(localPhotoPaths);

    sendToUI('job-progress', { jobId, status: 'review', message: '👀 Review the listing — click Publish when ready', progress: 90 });
    await updateJob(jobId, 'review', { message: 'Form filled — awaiting rep confirmation' });
    log('Form fill complete — awaiting review');

    await client.close();

  } catch(e) {
    log('CDP agent error: ' + e.message);
    if (client) try { await client.close(); } catch(ex) {}
    await updateJob(jobId, 'failed', { error: e.message });
    sendToUI('job-progress', { jobId, status: 'failed', message: 'Error: ' + e.message, progress: 0 });
  }
}

// ── Main export ───────────────────────────────────────────
module.exports = {
  runJob: async function(job, sendToUI) {
    log('Received job: ' + job.id);
    try {
      await runCDPAgent(job, sendToUI);
      // Log to comm_log
      await logToCommLog(
        job.rep_id,
        job.vehicle_id,
        'posted_to_facebook',
        (job.payload?.vehicle?.year || '') + ' ' + (job.payload?.vehicle?.make || '') + ' ' + (job.payload?.vehicle?.model || '')
      );
    } catch(e) {
      log('runJob error: ' + e.message);
      await updateJob(job.id, 'failed', { error: e.message });
    }
  }
};
