const { app, BrowserWindow, shell, ipcMain } = require('electron');
const agent = require('./agent');
const path = require('path');
const https = require('https');
const fs = require('fs');
const os = require('os');
const cp = require('child_process');

// ── Config ──────────────────────────────────────────────
const VERSION       = '1.1.6';
const SUPABASE_URL  = 'dmeigygmmxwmkyniizzj.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRtZWlneWdtbXh3bWt5bmlpenpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI1NzU2NDEsImV4cCI6MjA4ODE1MTY0MX0.hTv4RICUBNWFNLsQEaZVqcbviqD0ZZSinwCzdSLRDJo';
const CRM_URL       = 'https://hocrm-frontend.onrender.com';
const PROFILE_NAME  = 'Revora';

// ── Paths ────────────────────────────────────────────────
const DATA_DIR    = path.join(os.homedir(), 'AppData', 'Roaming', 'Revora');
const SESSION_FILE= path.join(DATA_DIR, 'session.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ── Machine ID ───────────────────────────────────────────
const crypto = require('crypto');
const MACHINE_ID_FILE = path.join(DATA_DIR, 'machine.json');
const VERSION_URL = 'https://raw.githubusercontent.com/loganhopvlogs-coder/revora-releases/main/version.json';
const UPDATE_DIR  = path.join(DATA_DIR, 'updates');

function getMachineId() {
  // Return existing machine ID or generate a new unique one
  try {
    if (fs.existsSync(MACHINE_ID_FILE)) {
      const data = JSON.parse(fs.readFileSync(MACHINE_ID_FILE, 'utf8'));
      if (data.machine_id) return data.machine_id;
    }
  } catch(e) {}

  // Generate from hostname + username + random salt
  const raw = os.hostname() + os.userInfo().username + crypto.randomBytes(8).toString('hex');
  const machine_id = crypto.createHash('sha256').update(raw).digest('hex').slice(0, 32);
  fs.writeFileSync(MACHINE_ID_FILE, JSON.stringify({
    machine_id,
    created_at: new Date().toISOString(),
    hostname: os.hostname(),
    username: os.userInfo().username
  }));
  log('New machine ID generated: ' + machine_id);
  return machine_id;
}

const MACHINE_ID = getMachineId();
log('Machine ID: ' + MACHINE_ID);

// ── Register machine in Supabase ──────────────────────────
async function registerMachine(repId) {
  try {
    const body = {
      machine_id: MACHINE_ID,
      rep_id: repId || null,
      hostname: os.hostname(),
      username: os.userInfo().username,
      version: VERSION,
      last_seen: new Date().toISOString()
    };
    // Upsert — insert or update on conflict
    await sbRequest('/rest/v1/machines?on_conflict=machine_id', 'POST', body);
    log('Machine registered: ' + MACHINE_ID);
  } catch(e) {
    log('Machine register error: ' + e.message);
  }
}

// ── Update checker ────────────────────────────────────────
function httpsGet(url) {
  return new Promise((resolve, reject) => {
    https.get(url, res => {
      // Follow redirects
      if (res.statusCode === 301 || res.statusCode === 302) {
        return httpsGet(res.headers.location).then(resolve).catch(reject);
      }
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

function downloadFile(url, dest) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest);
    const get = (u) => {
      https.get(u, res => {
        if (res.statusCode === 301 || res.statusCode === 302) {
          return get(res.headers.location);
        }
        res.pipe(file);
        file.on('finish', () => { file.close(); resolve(dest); });
      }).on('error', e => { fs.unlink(dest, () => {}); reject(e); });
    };
    get(url);
  });
}

function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('data', d => hash.update(d));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

async function checkForUpdates() {
  try {
    log('Checking for updates...');
    const raw = await httpsGet(VERSION_URL);
    const remote = JSON.parse(raw);
    log('Remote version: ' + remote.version + ' | Local: ' + VERSION);

    if (remote.version === VERSION) {
      log('Already up to date');
      return;
    }

    log('Update available: ' + remote.version);

    // Notify UI
    if (mainWindow) {
      mainWindow.webContents.send('update-available', {
        version: remote.version,
        notes: remote.notes,
        required: remote.required
      });
    }

    // Download update
    if (!fs.existsSync(UPDATE_DIR)) fs.mkdirSync(UPDATE_DIR, { recursive: true });
    const zipPath = path.join(UPDATE_DIR, 'Revora-' + remote.version + '.zip');

    log('Downloading update from: ' + remote.url);
    await downloadFile(remote.url, zipPath);

    // Verify checksum
    const localChecksum = await sha256File(zipPath);
    log('Downloaded checksum: ' + localChecksum);
    log('Expected checksum:   ' + remote.checksum);

    if (localChecksum !== remote.checksum) {
      fs.unlinkSync(zipPath);
      log('CHECKSUM MISMATCH — update aborted for security');
      if (mainWindow) mainWindow.webContents.send('update-failed', { reason: 'Checksum mismatch' });
      return;
    }

    log('Checksum verified ✅ — update ready to install');
    pendingUpdate = { version: remote.version, zipPath, notes: remote.notes, required: remote.required };
    if (mainWindow) {
      mainWindow.webContents.send('update-ready', pendingUpdate);
    }

  } catch(e) {
    log('Update check error: ' + e.message);
  }
}

// ── Apply update (called from UI confirm) ─────────────────
async function applyUpdate(zipPath) {
  try {
    log('Applying update from: ' + zipPath);
    const AdmZip = require('adm-zip');
    const zip = new AdmZip(zipPath);
    const appDir = __dirname;

    // Extract to temp dir first
    const tempDir = path.join(UPDATE_DIR, 'extracted');
    zip.extractAllTo(tempDir, true);

    // Copy files over (skip node_modules)
    const entries = fs.readdirSync(tempDir);
    for (const entry of entries) {
      if (entry === 'node_modules') continue;
      const src  = path.join(tempDir, entry);
      const dest = path.join(appDir, entry);
      fs.cpSync(src, dest, { recursive: true, force: true });
    }

    // Clean up
    fs.unlinkSync(zipPath);
    fs.rmSync(tempDir, { recursive: true, force: true });

    log('Update applied — restarting');
    app.relaunch();
    app.exit(0);
  } catch(e) {
    log('Apply update error: ' + e.message);
    if (mainWindow) mainWindow.webContents.send('update-failed', { reason: e.message });
  }
}

// ── State ─────────────────────────────────────────────────
let mainWindow    = null;
let currentSession= null;
let heartbeatTimer= null;
let pendingUpdate = null; // { version, zipPath, notes }

// ── Logger ───────────────────────────────────────────────
const LOG_FILE = path.join(DATA_DIR, 'revora.log');
function log(msg) {
  const line = '[' + new Date().toLocaleTimeString() + '] ' + msg;
  console.log(line);
  try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch(e) {}
}

// ── Supabase helper ───────────────────────────────────────
function sbRequest(path, method, body, token) {
  return new Promise((resolve, reject) => {
    const postData = body ? JSON.stringify(body) : null;
    const opts = {
      hostname: 'dmeigygmmxwmkyniizzj.supabase.co',
      path,
      method: method || 'GET',
      headers: {
        'apikey': SUPABASE_ANON,
        'Authorization': 'Bearer ' + (token || SUPABASE_ANON),
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal',
        ...(postData ? { 'Content-Length': Buffer.byteLength(postData) } : {})
      }
    };
    const req = https.request(opts, (res) => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); } catch(e) { resolve(data); }
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

// ── IPC: Update handlers ─────────────────────────────────
ipcMain.handle('apply-update', async (event, zipPath) => {
  await applyUpdate(zipPath);
});
ipcMain.handle('get-machine-id', () => MACHINE_ID);
ipcMain.handle('check-updates', async () => {
  await checkForUpdates();
  return pendingUpdate; // return state directly so UI doesn't miss the event
});
ipcMain.handle('get-pending-update', () => pendingUpdate);
ipcMain.handle('clear-pending-update', () => { pendingUpdate = null; });

// ── Create main window ────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 420,
    height: 740,
    resizable: false,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: '#0D0D14',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
    icon: path.join(__dirname, 'ui', 'icon.png')
  });

  mainWindow.loadFile(path.join(__dirname, 'ui', 'index.html'));

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// ── IPC handlers — bridge between UI and Node ─────────────

// Session save — called from UI after successful login
ipcMain.handle('save-session', async (event, session) => {
  try {
    currentSession = session;
    fs.writeFileSync(SESSION_FILE, JSON.stringify(session));
    log('Session saved: ' + session?.user?.email);
    startHeartbeat();
    registerMachine(session?.user?.id);
    return { ok: true };
  } catch(e) {
    return { error: e.message };
  }
});

// Login
ipcMain.handle('login', async (event, { email, password }) => {
  try {
    const data = await sbRequest(
      '/auth/v1/token?grant_type=password',
      'POST',
      { email, password }
    );
    if (data.access_token) {
      currentSession = data;
      fs.writeFileSync(SESSION_FILE, JSON.stringify(data));
      startHeartbeat();
    }
    return data;
  } catch(e) {
    return { error: e.message };
  }
});

// Load saved session
ipcMain.handle('get-session', async () => {
  try {
    if (currentSession) return currentSession;
    if (fs.existsSync(SESSION_FILE)) {
      const data = JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8'));
      if (data?.access_token) {
        // Verify still valid
        const user = await sbRequest('/auth/v1/user', 'GET', null, data.access_token);
        if (user?.id) {
          data.user = user;
          currentSession = data;
          startHeartbeat();
          return data;
        }
      }
    }
  } catch(e) {}
  return null;
});

// Supabase query
ipcMain.handle('sb-fetch', async (event, { path: sbPath, token }) => {
  try {
    return await sbRequest(sbPath, 'GET', null, token || currentSession?.access_token);
  } catch(e) {
    return { error: e.message };
  }
});

// Sign out
ipcMain.handle('signout', async () => {
  currentSession = null;
  clearInterval(heartbeatTimer);
  try { fs.unlinkSync(SESSION_FILE); } catch(e) {}
  return { ok: true };
});

// Open CRM in existing Chrome
ipcMain.handle('open-crm', async () => {
  shell.openExternal(CRM_URL);
  return { ok: true };
});

// Window controls
ipcMain.on('minimize', () => mainWindow?.minimize());
ipcMain.on('maximize', () => {
  if (mainWindow?.isMaximized()) mainWindow.unmaximize();
  else mainWindow?.maximize();
});
ipcMain.on('close', () => mainWindow?.close());

// Open Facebook in Revora Chrome profile
ipcMain.handle('open-facebook', async () => {
  const chromePaths = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    path.join(os.homedir(), 'AppData\\Local\\Google\\Chrome\\Application\\chrome.exe')
  ];
  let chromePath = null;
  for (const p of chromePaths) {
    if (fs.existsSync(p)) { chromePath = p; break; }
  }
  if (!chromePath) return { error: 'Chrome not found' };

  const userDataDir = path.join(os.homedir(), 'AppData', 'Local', 'Google', 'Chrome', 'User Data');
  cp.spawn(chromePath, [
    `--profile-directory=${PROFILE_NAME}`,
    `--user-data-dir=${userDataDir}`,
    '--no-first-run',
    'https://www.facebook.com/marketplace/create/vehicle'
  ], { detached: true, stdio: 'ignore' }).unref();

  return { ok: true };
});

// Get version
ipcMain.handle('get-version', () => VERSION);

// ── Jobs table check — create if missing ─────────────────
async function ensureJobsTable() {
  // Jobs table may not exist yet — silently handle
  try {
    await sbRequest('/rest/v1/jobs?limit=1', 'GET', null, SUPABASE_ANON);
  } catch(e) {}
}

// ── Heartbeat ─────────────────────────────────────────────
function startHeartbeat() {
  clearInterval(heartbeatTimer);
  log('Heartbeat started for: ' + (currentSession?.user?.email || 'unknown'));

  heartbeatTimer = setInterval(async () => {
    if (!currentSession?.user?.id) return;
    try {
      // 1. Check if user is still authorized
      const userCheck = await sbRequest(
        '/rest/v1/users?select=id,status&id=eq.' + currentSession.user.id + '&limit=1',
        'GET', null, SUPABASE_ANON
      );
      if (!userCheck?.length || userCheck[0]?.status === 'disabled' || userCheck[0]?.status === 'terminated') {
        log('User revoked — locking EXE');
        currentSession = null;
        try { fs.unlinkSync(SESSION_FILE); } catch(e) {}
        mainWindow?.webContents.send('force-logout', { reason: 'Account access has been revoked.' });
        clearInterval(heartbeatTimer);
        return;
      }

      // 2. Check for pending jobs
      const jobs = await sbRequest(
        '/rest/v1/jobs?select=*&rep_id=eq.' + currentSession.user.id + '&status=eq.pending&order=created_at.asc&limit=1',
        'GET', null, SUPABASE_ANON
      );
      if (Array.isArray(jobs) && jobs.length > 0) {
        const job = jobs[0];
        log('Job found: ' + job.id + ' vehicle: ' + job.vehicle_id);

        // Mark as in_progress immediately so no other instance picks it up
        try {
          await sbRequest(
            '/rest/v1/jobs?id=eq.' + job.id,
            'PATCH',
            { status: 'in_progress' },
            SUPABASE_ANON
          );
        } catch(e) { log('Job update error: ' + e.message); }

        // Notify UI
        mainWindow?.webContents.send('new-job', job);

        // Run the agent — fills Facebook form automatically
        agent.runJob(job, (event, data) => {
          mainWindow?.webContents.send(event, data);
        }).catch(e => log('Agent error: ' + e.message));
      }

      // 3. Update last seen timestamp (silently fail if column missing)
      try {
        await sbRequest(
          '/rest/v1/users?id=eq.' + currentSession.user.id,
          'PATCH',
          { last_seen: new Date().toISOString() },
          SUPABASE_ANON
        );
      } catch(e) { /* column may not exist yet */ }

    } catch(e) {
      log('Heartbeat error: ' + e.message);
    }
  }, 5000);
}

// ── Open Chrome with Revora profile ──────────────────────
function openChrome(url) {
  const chromePaths = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    path.join(os.homedir(), 'AppData', 'Local', 'Google', 'Chrome', 'Application', 'chrome.exe')
  ];
  let chromePath = null;
  for (const p of chromePaths) {
    if (fs.existsSync(p)) { chromePath = p; break; }
  }
  if (!chromePath) { log('Chrome not found'); return; }

  const userDataDir = path.join(os.homedir(), 'AppData', 'Local', 'Google', 'Chrome', 'User Data');
  log('Opening Chrome with Revora profile: ' + url);
  cp.spawn(chromePath, [
    '--profile-directory=Revora',
    '--user-data-dir=' + userDataDir,
    '--no-first-run',
    url
  ], { detached: true, stdio: 'ignore' }).unref();
}

// ── Suppress non-critical warnings ──────────────────────
process.on('uncaughtException', (err) => {
  if (err.message?.includes('dragEvent') || err.message?.includes('fetch')) return;
  console.error('Uncaught:', err.message);
});

// ── App lifecycle ─────────────────────────────────────────
app.whenReady().then(async () => {
  createWindow();

  // Register machine when session loads
  try {
    if (fs.existsSync(SESSION_FILE)) {
      const session = JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8'));
      if (session?.user?.id) {
        registerMachine(session.user.id);
      }
    }
  } catch(e) {}
  ensureJobsTable();
  // Restore session and start heartbeat if already logged in
  try {
    if (fs.existsSync(SESSION_FILE)) {
      const saved = JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8'));
      if (saved?.user?.id) {
        currentSession = saved;
        log('Session restored: ' + saved.user.email);
        setTimeout(() => startHeartbeat(), 3000); // delay so window loads first
      }
    }
  } catch(e) { log('Session restore error: ' + e.message); }
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
